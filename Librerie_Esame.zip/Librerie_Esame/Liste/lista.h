#include <iostream>

struct list{
  int valore;
  list* next;
};

/*Funzione per creare un nuovo nodo nella lista*/
list* nuovaCella            (int);
/*Funzione per cercare un valore nella lista*/
bool emptyList              (list*, list*);
bool findVal                (list*, int);
/**/
void swap                   (int &, int &);
/**/
/*Funzioni per aggiungere elementi alla lista*/
void addTailAndHead         (list* &, int);
void addHead                (list* &, int);
void addTail                (list* &, int);
/*Funzione per eliminare elementi dalla lista*/
void deleteList             (list* &);
void deleteTailAndHead      (list *&);
void deleteTail             (list* &);
void deleteHead             (list* &);
void deleteElem             (list* &, int);
/*Funzione per stampare tutti i valori nella lista, se non vuota*/
void printList              (list* );
/*Funzioni ordine lista*/
void sortListCrescente      (list*, list*);
void sortListDecrescente    (list*, list*);
