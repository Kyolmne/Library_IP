#include "vettore.h"

int main(){
  std::vector <int> v;
  std::vector <int> b;
  for (int i = 0; i < 10; i ++){v.push_back(i+10);}
  for (int i = 0; i < 10; i ++){b.push_back(i+5);}
  
  std::cout << "UNIONE VETTORI " << std::endl;
  printVector(unionVector(v, b));
  std::cout << "INTERSEZIONE VETTORI " << std::endl;
  printVector(intersectVector(v, b));

  return 1;
}