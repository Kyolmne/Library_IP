#include <iostream>

/*array sort*/
void selectionSort      (int* &, int);
void insertionSort      (int* &, int);
void bubbleSort         (int* &, int);
/*copia array*/
void deepCopy           (int*, int, int* &);
/*stampa array*/
void printArray         (int*, int);