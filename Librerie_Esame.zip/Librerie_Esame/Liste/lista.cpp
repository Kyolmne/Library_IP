#include "lista.h"




list* nuovaCella (int valore){
  list* cella = new list;
  cella->valore = valore;
  cella->next = nullptr;
  return cella;
}

bool emptyList (list *l){
  return (l == nullptr);
}

bool findVal(list* lista, int val){
  if (lista != nullptr){
    if (lista->valore == val){
      return true;
    }
    return findVal(lista->next, val);
  }
  return false;
}

void swap(int &a, int &b){
  int c = a;
  a = b;
  b = c;
}

void addTailAndHead(list* &lista, int valore){
  addTail(lista, valore);
  addHead(lista, valore);
}

void addHead (list* &lista, int valore){
  list* cella = nuovaCella(valore);
  cella->next = lista;
  lista = cella;
}

void addTail (list* &lista, int valore){
  if (lista != nullptr){
    addTail(lista->next, valore);
  }else{
    lista = nuovaCella(valore);
  }
}

void deleteList (list* &lista){
  if (lista != nullptr){
    deleteList(lista->next);
    delete lista;
    lista = nullptr;
  }
}

void deleteTailAndHead(list *&lista){
  deleteTail(lista);
  deleteHead(lista);
}

void deleteTail (list* &lista){
  if (lista->next != nullptr){
    deleteTail(lista->next);
  }else{
    delete lista;
    lista = nullptr;
  }
}

void deleteHead (list* &lista){
  list* cella = lista->next;
  delete lista;
  lista = cella;
}

void deleteElem (list* &lista, int valore){
  if (lista != nullptr){
    if (lista->valore == valore){
      list* rem = lista->next;
      delete lista;
      lista = rem;
      deleteElem(lista, valore);
    }else{
      deleteElem(lista->next, valore);
    }
  }
}

void printList(list* lista){
  static int i = 1;
  if (lista == nullptr && i == 1) std::cout << ">La lista è vuota " << std::endl;
  else if (lista != nullptr){
    std::cout << i << ">Valore della cella: " << lista->valore << std::endl;
    i++;
    printList(lista->next);
  }
  i = 1;
}

void sortListCrescente(list* l, list* start){
  if(start != nullptr){
    if(l != nullptr){
      if (start->valore > l->valore){
        swap(l->valore, start->valore);
      }
      sortListCrescente(l->next, start);
    }else{
      sortListCrescente(start->next, start->next);
    }
  }
}

void sortListDecrescente(list* l, list* start){
    if(start != nullptr){
    if(l != nullptr){
      if (start->valore < l->valore){
        swap(l->valore, start->valore);
      }
      sortListDecrescente(l->next, start);
    }else{
      sortListDecrescente(start->next, start->next);
    }
  }

}
