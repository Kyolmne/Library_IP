#include "vettore.h"

void printVector(std::vector <int> a){
  for (int cella = 0; cella < a.size(); cella++){std::cout << ">valore cella: " << a.at(cella) << std::endl;}
}

bool searchValue(std::vector<int> vettore, int valore){
  for (int cell = 0; cell < vettore.size(); cell++){
    if (vettore.at(cell) == valore) return true;
  }
  return false;
}

std::vector<int> unionVector(std::vector<int> a, std::vector<int> b){
  std::vector<int> finalVector(a);
  for (int cell_b = 0; cell_b < b.size(); cell_b++){
    if (!searchValue(finalVector, b.at(cell_b))) finalVector.push_back(b.at(cell_b));
  }
  return finalVector;
}

std::vector<int> intersectVector(std::vector<int> a, std::vector<int> b){
  std::vector<int> finalVector;
  std::vector<int> majorVector = ((a.size() > b.size())? a : b);
  for (int cella = 0; cella < majorVector.size(); cella++ ){
    if (searchValue(b, majorVector.at(cella))){
      if (!searchValue(finalVector, majorVector.at(cella))) finalVector.push_back(majorVector.at(cella));
    }
  }
  return finalVector;
}
