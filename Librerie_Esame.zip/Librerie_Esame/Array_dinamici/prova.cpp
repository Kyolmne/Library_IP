#include "array_dinamico.h"


int main(){
  srand(time(NULL));

  int *arr = new int [100];
  for (int x = 0; x < 100; x++) arr[x] = rand()%100;

  int *c   = new int [20];
  for (int x = 0; x < 20; x++) c[x] = x;
  
  std::cout << "Valore: " << std::endl;

  insertionSort(arr, 100);
  printArray(arr, 100);


  return 1;
}