#include "lista.h"


int main(){
  list* l = nullptr;
    
  printList(l);
  /*Prova aggiunta valori nella lista*/
  addTailAndHead(l, 10);
  addHead(l, 20);
  addTail(l, 30);
  /*Stampa*/
  printList(l);
  /*Cerca valori nella lista*/
  std::cout << findVal(l, 20) << std::endl;
  std::cout << findVal(l, 80) << std::endl;
  /**/

  addTailAndHead(l, 11);
  addHead(l, 12);
  addTail(l, 33);
  addTailAndHead(l, 120);
  addHead(l, 230);
  addTail(l, 3);
  sortListCrescente(l, l);
  printList(l);

  sortListDecrescente(l, l);
  printList(l);

  /*Delete lista head e tail*/
  deleteHead(l);
  deleteTail(l);
  /*Ristampa per verificare lo stato della listas*/
 // printList(l);
  /*Delete della lista in base al valore*/
  deleteElem(l, 10);
  //printList(l);
  return 1;
}