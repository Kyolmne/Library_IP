#include "array_dinamico.h"

void swap(int &a, int &b){
  int c = b;
  b = a;
  a = c;
}

void selectionSort(int* &arr, int size){
  for (int cella = 0; cella < size; cella++){
    int min = cella;
    for (int confronto = cella+1; confronto < size; confronto++){
      if (arr[cella] < arr[confronto]) min = confronto;
    }
    swap(arr[cella], arr[min]);
  }
}

void insertionSort(int *&arr, int size){
  for (int j = 1; j < size; j++){
    if (arr[j] > arr[j-1]){
      int location = j;
      int temp = arr[j];
      do{
        arr[location] = arr[location-1];
        location--;
      }while(location > 0 && arr[location-1] < temp);
      arr[location] = temp;
    }
  }
}

void bubbleSort(int* &arr, int size){
  for (int i=0; i < size; i++){
    for (int j=0; j<size; j++){
      if(arr[j]>arr[j+1]){
        swap(arr[j], arr[j+1]);
      }
    }
  }
}

void deepCopy (int* arr, int size, int*& copy){
  delete copy;
  copy = new int[size];
  for (int i = 0 ; i < size; i++){
    copy[i] = arr[i];
  }
  
}

void printArray (int* arr, int size){
  for (int n = 0; n < size; n++){
    std::cout << n << ">" <<  arr[n] << std::endl;
  }
}
