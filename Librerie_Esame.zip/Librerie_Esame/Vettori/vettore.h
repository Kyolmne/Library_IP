#include <iostream>
#include <vector>

/*stampa del vettore*/
void printVector                      (std::vector <int>);
/*unione e interszione del vettore*/
std::vector<int> unionVector          (std::vector<int>, std::vector<int>);
std::vector<int> intersectVector      (std::vector<int>, std::vector<int>);


